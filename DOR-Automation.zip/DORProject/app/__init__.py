from flask import Flask
from .utils.database import get_db, close_db
from .models import create_tables
from .routes import main
from .extensions import db, login

def create_app():
    app = Flask(__name__)
    app.config.from_object("DORProject.app.config.Config")
    app.register_blueprint(main)

    # Initialize extensions
    db.init_app(app)
    login.init_app(app)

    # Create tables within the app context
    with app.app_context():
        create_tables()

    # Database connection and teardown
    @app.before_request
    def before_request():
        get_db()

    @app.teardown_appcontext
    def teardown_appcontext(exception):
        close_db()

    return app