import os

class Config:
    BASE_DIR = os.path.abspath(os.path.dirname(__file__) + "/../..")
    SQLALCHEMY_DATABASE_URI = f"sqlite:///{BASE_DIR}/DORProject/instance/dor_reports.db"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SECRET_KEY = "default_secret_key"
