from flask import Blueprint
# from .routes import index  # Commented out because the module does not exist
from .routes import main


# Define un nombre único para este Blueprint
bp = Blueprint("index", __name__)  # Cambia "main" por un nombre único si tienes otros Blueprints

# Importa las rutas específicas
from .example_route import example_route

# Agrega las rutas al Blueprint
bp.add_url_rule("/example", view_func=example_route)
