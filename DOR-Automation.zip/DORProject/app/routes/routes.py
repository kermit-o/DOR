from flask import Blueprint, render_template, request, redirect, url_for, send_from_directory, flash, after_this_request
import os
from ..models import DORReport  # Relative import
from ..utils.upload_handler import handle_file_upload  # Relative import
from ..utils.pdf_utils import export_report_to_pdf  # Relative import
from ..extensions import db  # Relative import

UPLOAD_FOLDER = 'uploads'
PUBLIC_FOLDER = '/var/www/html/download'

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(PUBLIC_FOLDER, exist_ok=True)

main = Blueprint('main', __name__, template_folder='../templates')

@main.route('/')
def index():
    return render_template('upload.html')

@main.route('/reports', methods=['GET', 'POST'])
def list_reports():
    if request.method == 'POST':
        filter_filename = request.form.get('filename')
        if filter_filename:
            reports = DORReport.query.filter(DORReport.filename.contains(filter_filename)).all()
        else:
            reports = DORReport.query.all()
    else:
        reports = DORReport.query.all()

    return render_template('reports.html', reports=reports)

@main.route('/download/<filename>')
def download_file(filename):
    @after_this_request
    def remove_file(response):
        try:
            os.remove(os.path.join(PUBLIC_FOLDER, filename))
            print(f"Removed file {filename} from public folder")
        except Exception as e:
            print(f"Error removing file {filename}: {e}")
        return response

    return send_from_directory(PUBLIC_FOLDER, filename)

@main.route('/files')
def list_files():
    files = os.listdir(UPLOAD_FOLDER)
    return render_template('files.html', files=files)

@main.route('/delete/<filename>', methods=['POST'])
def delete_file(filename):
    file_path = os.path.join(UPLOAD_FOLDER, filename)
    try:
        os.remove(file_path)
        flash(f"File {filename} deleted successfully.", "success")
    except Exception as e:
        flash(f"Error deleting file {filename}: {str(e)}", "error")
    return redirect(url_for('main.list_files'))

@main.route('/upload', methods=['POST'])
def upload_dor_file():
    return handle_file_upload(request, UPLOAD_FOLDER, PUBLIC_FOLDER)

@main.route('/export/<int:report_id>')
def export_report(report_id):
    report = DORReport.query.get_or_404(report_id)
    pdf_path = export_report_to_pdf(report, UPLOAD_FOLDER)
    return f"PDF generated successfully! <a href='/download/{os.path.basename(pdf_path)}'>Download PDF</a>"