# DOR Automation Project

Automate DOR report generation.